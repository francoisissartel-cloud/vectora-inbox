"""Package matching - Détermination des items pertinents par domaine (Phase 2)."""
