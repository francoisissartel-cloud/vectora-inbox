"""Package scoring - Calcul des scores de pertinence (Phase 3)."""
