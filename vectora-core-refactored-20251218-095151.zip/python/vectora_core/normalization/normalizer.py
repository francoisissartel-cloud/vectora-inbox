"""
Module principal de normalisation des items.

Ce module orchestre la normalisation d'un item brut en item structuré,
en combinant :
- Détection par règles (scopes canonical)
- Détection par Bedrock (IA)
- Validation et filtrage
"""

import logging
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed

from vectora_core.normalization import bedrock_client, entity_detector
from vectora_core.normalization.domain_context_builder import DomainContextBuilder

logger = logging.getLogger(__name__)

# Limite de parallélisation pour réduire le débit vers Bedrock
# DEV: 1 worker pour éviter throttling, PROD: 4 workers
import os
MAX_BEDROCK_WORKERS = 1 if os.environ.get('ENV') == 'dev' else 4


def normalize_item(
    raw_item: Dict[str, Any],
    canonical_scopes: Dict[str, Any],
    bedrock_model_id: str,
    watch_domains: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Normalise un item brut en item structuré.
    
    Processus :
    1. Construire le texte complet (titre + description)
    2. Détecter les entités par règles (scopes canonical)
    3. Appeler Bedrock pour extraction + classification + résumé
    4. Fusionner les résultats Bedrock + règles
    5. Retourner l'item normalisé
    
    Args:
        raw_item: Item brut contenant title, url, raw_text, source_key, etc.
        canonical_scopes: Scopes canonical chargés
        bedrock_model_id: Identifiant du modèle Bedrock
    
    Returns:
        Item normalisé contenant :
        - source_key: identifiant de la source
        - source_type: type de source
        - title: titre de l'item
        - summary: résumé généré par Bedrock
        - url: lien vers l'article original
        - date: date de publication
        - companies_detected: liste de sociétés
        - molecules_detected: liste de molécules
        - technologies_detected: liste de technologies
        - indications_detected: liste d'indications
        - event_type: type d'événement
    """
    logger.debug(f"Normalisation de l'item : {raw_item.get('title', '')[:50]}...")
    
    # Construire le texte complet pour analyse
    full_text = f"{raw_item.get('title', '')} {raw_item.get('raw_text', '')}"
    
    # Étape 1 : Détection par règles
    rules_result = entity_detector.detect_entities_by_rules(full_text, canonical_scopes)
    
    # Étape 2 : Préparer des exemples pour Bedrock depuis les scopes
    canonical_examples = _extract_canonical_examples_enhanced(canonical_scopes)
    
    # Étape 2.5 : Construire les contextes de domaines si watch_domains fourni
    domain_contexts = []
    if watch_domains:
        domain_builder = DomainContextBuilder(canonical_scopes)
        domain_contexts = domain_builder.build_domain_contexts(watch_domains)
    
    # Étape 3 : Appeler Bedrock
    bedrock_result = bedrock_client.normalize_item_with_bedrock(
        full_text,
        bedrock_model_id,
        canonical_examples,
        domain_contexts
    )
    
    # Étape 4 : Fusionner les résultats
    merged_entities = entity_detector.merge_entity_detections(bedrock_result, rules_result)
    
    # Étape 4.5 : Matching Bedrock par domaines (NOUVEAU)
    bedrock_matching_result = {}
    if watch_domains:
        try:
            from vectora_core.matching import bedrock_matcher
            
            # Construire l'item partiel pour le matching
            item_for_matching = {
                'title': raw_item.get('title', ''),
                'summary': bedrock_result.get('summary', ''),
                'entities': {
                    'companies': merged_entities['companies_detected'],
                    'molecules': merged_entities['molecules_detected'],
                    'technologies': merged_entities['technologies_detected'],
                    'trademarks': bedrock_result.get('trademarks_detected', []),
                    'indications': merged_entities['indications_detected']
                },
                'event_type': bedrock_result.get('event_type', 'other')
            }
            
            # Appel Bedrock matching
            bedrock_matching_result = bedrock_matcher.match_watch_domains_with_bedrock(
                item_for_matching, watch_domains, canonical_scopes, bedrock_model_id
            )
            
            logger.debug(f"Matching Bedrock terminé: {len(bedrock_matching_result.get('matched_domains', []))} domaines")
            
        except Exception as e:
            logger.warning(f"Erreur lors du matching Bedrock: {e}")
            # Continuer sans matching Bedrock (fallback sur matching déterministe)
            bedrock_matching_result = {'matched_domains': [], 'domain_relevance': {}}
    
    # Étape 5 : Construire l'item normalisé avec champs LAI et matching
    normalized_item = {
        'source_key': raw_item.get('source_key'),
        'source_type': raw_item.get('source_type'),
        'title': raw_item.get('title'),
        'summary': bedrock_result.get('summary', ''),
        'url': raw_item.get('url'),
        'date': raw_item.get('published_at'),
        'companies_detected': merged_entities['companies_detected'],
        'molecules_detected': merged_entities['molecules_detected'],
        'technologies_detected': merged_entities['technologies_detected'],
        'trademarks_detected': bedrock_result.get('trademarks_detected', []),
        'indications_detected': merged_entities['indications_detected'],
        'event_type': bedrock_result.get('event_type', 'other'),
        'lai_relevance_score': bedrock_result.get('lai_relevance_score', 0),
        'anti_lai_detected': bedrock_result.get('anti_lai_detected', False),
        'pure_player_context': bedrock_result.get('pure_player_context', False),
        'domain_relevance': bedrock_result.get('domain_relevance', []),
        # NOUVEAU : Résultats du matching Bedrock
        'bedrock_matched_domains': bedrock_matching_result.get('matched_domains', []),
        'bedrock_domain_relevance': bedrock_matching_result.get('domain_relevance', {})
    }
    
    return normalized_item


def normalize_items_batch(
    raw_items: List[Dict[str, Any]],
    canonical_scopes: Dict[str, Any],
    bedrock_model_id: str,
    watch_domains: List[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """
    Normalise un lot d'items bruts avec parallélisation contrôlée.
    
    Args:
        raw_items: Liste d'items bruts
        canonical_scopes: Scopes canonical
        bedrock_model_id: Identifiant du modèle Bedrock
    
    Returns:
        Liste d'items normalisés
    """
    logger.info(f"Normalisation de {len(raw_items)} items (max {MAX_BEDROCK_WORKERS} workers parallèles)")
    
    normalized_items = []
    failed_count = 0
    
    # Utiliser ThreadPoolExecutor avec un nombre limité de workers
    with ThreadPoolExecutor(max_workers=MAX_BEDROCK_WORKERS) as executor:
        # Soumettre toutes les tâches
        future_to_item = {
            executor.submit(normalize_item, raw_item, canonical_scopes, bedrock_model_id, watch_domains): raw_item
            for raw_item in raw_items
        }
        
        # Collecter les résultats au fur et à mesure
        for future in as_completed(future_to_item):
            raw_item = future_to_item[future]
            try:
                normalized = future.result()
                normalized_items.append(normalized)
            except Exception as e:
                failed_count += 1
                logger.error(
                    f"Erreur lors de la normalisation de l'item '{raw_item.get('title', '')[:50]}...': {e}"
                )
                # Continuer avec les autres items
    
    logger.info(
        f"Normalisation terminée : {len(normalized_items)} succès, {failed_count} échecs "
        f"sur {len(raw_items)} items"
    )
    
    return normalized_items


def _extract_canonical_examples_enhanced(canonical_scopes: Dict[str, Any]) -> Dict[str, List[str]]:
    """
    Extrait des exemples d'entités depuis les scopes canonical pour Bedrock avec focus LAI.
    
    Args:
        canonical_scopes: Scopes canonical complets
    
    Returns:
        Dictionnaire d'exemples par type d'entité avec priorité LAI
    """
    examples = {
        'companies': [],
        'molecules': [],
        'technologies': []
    }
    
    # Extraire des exemples de sociétés (augmenter à 50 pour meilleure couverture)
    company_scopes = canonical_scopes.get('companies', {})
    for scope_key, companies in company_scopes.items():
        if isinstance(companies, list):
            examples['companies'].extend(companies[:50])
            if len(examples['companies']) >= 50:
                break
    
    # Extraire des exemples de molécules
    molecule_scopes = canonical_scopes.get('molecules', {})
    for scope_key, molecules in molecule_scopes.items():
        if isinstance(molecules, list):
            examples['molecules'].extend(molecules[:30])
            if len(examples['molecules']) >= 30:
                break
    
    # Extraire des exemples de technologies
    tech_scopes = canonical_scopes.get('technologies', {})
    for scope_key, keywords in tech_scopes.items():
        if isinstance(keywords, list):
            examples['technologies'].extend(keywords[:20])
            if len(examples['technologies']) >= 20:
                break
    
    return examples
