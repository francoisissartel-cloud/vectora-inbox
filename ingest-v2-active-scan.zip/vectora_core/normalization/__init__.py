"""
Vectora Core V2 - Modules Normalization

Ce package contient la logique métier spécifique à la Lambda normalize-score V2 :
- Normalisation des items via Bedrock (extraction entités, classification)
- Matching des items aux domaines de veille du client
- Scoring de pertinence basé sur les règles métier
- Orchestration complète du workflow de normalisation et scoring

Fonction principale à implémenter :
- run_normalize_score_for_client() : Orchestration complète normalisation + scoring

Modules à implémenter :
- normalizer.py : Appels Bedrock pour normalisation
- matcher.py : Matching aux domaines de veille
- scorer.py : Calcul des scores de pertinence
- bedrock_client.py : Client Bedrock spécialisé
"""

# TODO: Implémenter les modules et la fonction d'orchestration
# selon le contrat normalize_score_v2.md

__all__ = [
    # "run_normalize_score_for_client",  # À implémenter
]