"""
Client Bedrock spécialisé pour la normalisation des items.

Ce module fournit une interface robuste pour les appels Bedrock
avec gestion des erreurs, retry automatique et prompts canoniques.
"""

import json
import logging
import time
from typing import Dict, Any, Optional

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class BedrockNormalizationClient:
    """Client Bedrock robuste pour la normalisation des items."""
    
    def __init__(self, model_id: str, region: str = "us-east-1"):
        """
        Initialise le client Bedrock.
        
        Args:
            model_id: Identifiant du modèle Bedrock
            region: Région AWS pour Bedrock
        """
        self.model_id = model_id
        self.region = region
        self.client = boto3.client("bedrock-runtime", region_name=region)
        
        logger.info(f"Client Bedrock initialisé : modèle={model_id}, région={region}")
    
    def normalize_item(self, item_text: str, canonical_examples: Dict, 
                      domain_contexts: Optional[list] = None) -> Dict[str, Any]:
        """
        Normalise un item via Bedrock avec retry automatique et prompts canoniques.
        
        Args:
            item_text: Texte de l'item à normaliser
            canonical_examples: Exemples depuis canonical scopes
            domain_contexts: Contextes de domaines (optionnel)
        
        Returns:
            Résultat de normalisation avec champs LAI
        """
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                start_time = time.time()
                
                # Construction du prompt canonique
                prompt = self._build_prompt_from_canonical(item_text, canonical_examples)
                
                # Appel Bedrock avec gestion d'erreurs
                response = self._invoke_bedrock_with_retry(prompt)
                
                # Parsing robuste avec validation LAI
                result = self._parse_response_with_validation(response)
                
                latency_ms = int((time.time() - start_time) * 1000)
                logger.debug(f"Normalisation réussie (tentative {attempt + 1}, {latency_ms}ms)")
                
                return result
                
            except Exception as e:
                error_msg = str(e)
                logger.warning(f"Échec normalisation (tentative {attempt + 1}/{max_retries}): {error_msg}")
                
                # Gestion spécifique du throttling
                if "ThrottlingException" in error_msg or "Rate limit" in error_msg:
                    wait_time = (2 ** attempt) + 1  # Backoff plus long pour throttling
                    logger.info(f"Throttling détecté, attente {wait_time}s")
                    time.sleep(wait_time)
                elif attempt < max_retries - 1:
                    # Backoff exponentiel standard
                    time.sleep(2 ** attempt)
                
                if attempt == max_retries - 1:
                    logger.error(f"Échec définitif après {max_retries} tentatives")
                    return self._create_fallback_result()
        
        return self._create_fallback_result()
    
    def _build_prompt_from_canonical(self, item_text: str, examples: Dict) -> str:
        """
        Construit le prompt depuis le template canonique avec substitution.
        
        Args:
            item_text: Texte de l'item
            examples: Exemples d'entités depuis canonical scopes
        
        Returns:
            Prompt final prêt pour Bedrock
        """
        # Template LAI canonique (fallback si canonical indisponible)
        canonical_template = """
Analyze the following biotech/pharma news item and extract structured information.

TEXT TO ANALYZE:
{{item_text}}

EXAMPLES OF ENTITIES TO DETECT:
- Companies: {{companies_examples}}
- Molecules/Drugs: {{molecules_examples}}
- Technologies: {{technologies_examples}}

LAI TECHNOLOGY FOCUS:
Detect these LAI (Long-Acting Injectable) technologies:
- Extended-Release Injectable
- Long-Acting Injectable
- Depot Injection
- Once-Monthly Injection
- Microspheres
- PLGA
- In-Situ Depot
- Hydrogel
- Subcutaneous Injection
- Intramuscular Injection

TRADEMARKS to detect:
- UZEDY, PharmaShell, SiliaShell, BEPO, Aristada, Abilify Maintena

TASK:
1. Generate a concise summary (2-3 sentences)
2. Classify event type: clinical_update, partnership, regulatory, scientific_paper, corporate_move, financial_results, safety_signal, manufacturing_supply, other
3. Extract ALL pharmaceutical/biotech company names
4. Extract ALL drug/molecule names (brand names, generic names)
5. Extract ALL technology keywords - FOCUS on LAI technologies
6. Extract ALL trademark names (® or ™ symbols)
7. Extract ALL therapeutic indications
8. Evaluate LAI relevance (0-10 score)
9. Detect anti-LAI signals: oral routes (tablets, capsules, pills)
10. Assess pure player context: LAI-focused company without explicit LAI mentions

RESPONSE FORMAT (JSON only):
{
  "summary": "...",
  "event_type": "...",
  "companies_detected": ["..."],
  "molecules_detected": ["..."],
  "technologies_detected": ["..."],
  "trademarks_detected": ["..."],
  "indications_detected": ["..."],
  "lai_relevance_score": 0,
  "anti_lai_detected": false,
  "pure_player_context": false
}

Respond with ONLY the JSON, no additional text.
"""
        
        # Substitution des placeholders
        prompt = canonical_template.replace("{{item_text}}", item_text)
        
        for key, value in examples.items():
            placeholder = f"{{{{{key}}}}}"
            prompt = prompt.replace(placeholder, value)
        
        return prompt
    
    def _invoke_bedrock_with_retry(self, prompt: str) -> Dict[str, Any]:
        """Effectue l'appel Bedrock avec gestion robuste des erreurs."""
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "temperature": 0.0,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        }
        
        try:
            response = self.client.invoke_model(
                modelId=self.model_id,
                body=json.dumps(body),
                contentType="application/json"
            )
            
            response_body = json.loads(response["body"].read())
            return response_body
            
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            if error_code == "ThrottlingException":
                raise Exception("Rate limit Bedrock atteint")
            elif error_code == "ValidationException":
                raise Exception("Paramètres Bedrock invalides")
            elif error_code == "ModelNotReadyException":
                raise Exception("Modèle Bedrock non disponible")
            else:
                raise Exception(f"Erreur Bedrock: {error_code}")
        
        except Exception as e:
            raise Exception(f"Erreur appel Bedrock: {str(e)}")
    
    def _parse_response_with_validation(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Parse la réponse Bedrock avec validation des champs LAI."""
        try:
            # Extraction du contenu de la réponse
            content = response.get("content", [])
            if not content:
                raise Exception("Réponse Bedrock vide")
            
            text_content = content[0].get("text", "")
            if not text_content:
                raise Exception("Contenu texte manquant dans la réponse")
            
            # Parsing du JSON
            text_content = text_content.strip()
            
            # Chercher le JSON dans la réponse
            start_idx = text_content.find("{")
            end_idx = text_content.rfind("}") + 1
            
            if start_idx == -1 or end_idx == 0:
                raise Exception("JSON non trouvé dans la réponse")
            
            json_str = text_content[start_idx:end_idx]
            result = json.loads(json_str)
            
            # Validation et normalisation des champs LAI obligatoires
            validated_result = self._validate_lai_fields(result)
            
            return validated_result
            
        except json.JSONDecodeError as e:
            raise Exception(f"JSON invalide dans la réponse Bedrock: {str(e)}")
        
        except Exception as e:
            raise Exception(f"Erreur parsing réponse Bedrock: {str(e)}")
    
    def _validate_lai_fields(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Valide et normalise les champs LAI spécialisés."""
        validated = {}
        
        # Champs obligatoires avec valeurs par défaut
        validated["summary"] = result.get("summary", "")
        validated["event_type"] = result.get("event_type", "other")
        
        # Listes d'entités (toujours des listes)
        validated["companies_detected"] = result.get("companies_detected", [])
        validated["molecules_detected"] = result.get("molecules_detected", [])
        validated["technologies_detected"] = result.get("technologies_detected", [])
        validated["trademarks_detected"] = result.get("trademarks_detected", [])
        validated["indications_detected"] = result.get("indications_detected", [])
        
        # Champs LAI spécialisés avec validation
        lai_score = result.get("lai_relevance_score", 0)
        try:
            validated["lai_relevance_score"] = max(0, min(10, int(lai_score)))
        except (ValueError, TypeError):
            validated["lai_relevance_score"] = 0
            logger.warning(f"Score LAI invalide: {lai_score}, utilisation de 0")
        
        validated["anti_lai_detected"] = bool(result.get("anti_lai_detected", False))
        validated["pure_player_context"] = bool(result.get("pure_player_context", False))
        
        # Validation des listes (s'assurer que ce sont des listes)
        for field in ["companies_detected", "molecules_detected", "technologies_detected", 
                     "trademarks_detected", "indications_detected"]:
            if not isinstance(validated[field], list):
                logger.warning(f"Champ {field} n'est pas une liste, conversion")
                validated[field] = []
        
        return validated
    
    def _create_fallback_result(self) -> Dict[str, Any]:
        """Crée un résultat de fallback en cas d'échec total."""
        return {
            "summary": "",
            "event_type": "other",
            "companies_detected": [],
            "molecules_detected": [],
            "technologies_detected": [],
            "trademarks_detected": [],
            "indications_detected": [],
            "lai_relevance_score": 0,
            "anti_lai_detected": False,
            "pure_player_context": False
        }