"""
Configuration Loader pour Vectora Inbox V2.

Ce module gère le chargement et la résolution des configurations depuis S3 :
- Configuration client (client_config/{client_id}.yaml)
- Catalogues canonical (sources, profils d'ingestion)
- Résolution des bouquets de sources en sources individuelles

Responsabilités :
- Charger les fichiers YAML depuis S3
- Résoudre les bouquets en liste de sources
- Calculer la fenêtre temporelle selon la hiérarchie de priorité
- Valider la cohérence des configurations avec Pydantic
"""

from typing import Any, Dict, List, Optional
import logging
try:
    from pydantic import BaseModel, Field, validator
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False
    BaseModel = object
    Field = lambda *args, **kwargs: None
    validator = lambda *args, **kwargs: lambda f: f
from . import s3_io

logger = logging.getLogger(__name__)


# ========================================================================
# MODÈLES PYDANTIC POUR VALIDATION
# ========================================================================

class SourceConfigModel(BaseModel):
    """Modèle de validation pour une source du catalogue."""
    source_key: str = Field(..., min_length=1)
    source_type: str
    homepage_url: str = Field(..., min_length=1)
    ingestion_mode: str
    ingestion_profile: Optional[str] = None
    enabled: bool = True
    timeout_seconds: Optional[int] = Field(default=30, ge=5, le=120)
    
    @validator('ingestion_mode')
    def validate_ingestion_mode(cls, v):
        valid_modes = ['rss', 'html', 'api', 'none']
        if v not in valid_modes:
            raise ValueError(f"ingestion_mode doit être dans {valid_modes}, reçu: {v}")
        return v
    
    @validator('source_type')
    def validate_source_type(cls, v):
        valid_types = ['press_corporate', 'press_sector', 'press_generic', 'api', 'unknown']
        if v not in valid_types:
            logger.warning(f"source_type non standard: {v}")
        return v


class ClientConfigModel(BaseModel):
    """Modèle de validation pour une configuration client."""
    client_profile: Dict[str, Any]
    source_config: Dict[str, Any]
    pipeline: Optional[Dict[str, Any]] = None
    
    @validator('client_profile')
    def validate_client_profile(cls, v):
        required_fields = ['name', 'active']
        for field in required_fields:
            if field not in v:
                raise ValueError(f"client_profile manque le champ requis: {field}")
        return v
    
    @validator('source_config')
    def validate_source_config(cls, v):
        if 'source_bouquets_enabled' not in v and 'sources_extra_enabled' not in v:
            raise ValueError("source_config doit contenir source_bouquets_enabled ou sources_extra_enabled")
        return v


# ========================================================================
# FONCTIONS DE CHARGEMENT
# ========================================================================


def load_client_config(client_id: str, config_bucket: str) -> Dict[str, Any]:
    """
    Charge la configuration d'un client depuis S3 avec validation Pydantic.
    
    Args:
        client_id: Identifiant du client (ex: "lai_weekly_v3")
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict contenant la configuration client complète
    
    Raises:
        ValueError: Si la configuration est invalide
        Exception: Si le fichier de config n'existe pas
    """
    key = f"clients/{client_id}.yaml"
    logger.info(f"Chargement de la configuration client : {client_id}")
    
    config = s3_io.read_yaml_from_s3(config_bucket, key)
    
    # Validation Pydantic (optionnelle)
    if PYDANTIC_AVAILABLE:
        try:
            ClientConfigModel(**config)
            logger.info(f"✅ Configuration client validée : {config.get('client_profile', {}).get('name', client_id)}")
        except Exception as e:
            logger.warning(f"⚠️ Validation Pydantic échouée pour {client_id}: {e}")
    
    return config


def load_source_catalog(config_bucket: str) -> Dict[str, Any]:
    """
    Charge le catalogue des sources depuis S3 avec validation Pydantic.
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict contenant sources et bouquets du catalogue canonical
    
    Raises:
        ValueError: Si une source est invalide
        Exception: Si le catalogue n'existe pas
    """
    key = "canonical/sources/source_catalog.yaml"
    logger.info("Chargement du catalogue des sources")
    
    catalog = s3_io.read_yaml_from_s3(config_bucket, key)
    
    # Validation Pydantic de chaque source (optionnelle)
    sources = catalog.get('sources', [])
    invalid_sources = []
    
    if PYDANTIC_AVAILABLE:
        for source in sources:
            try:
                SourceConfigModel(**source)
            except Exception as e:
                source_key = source.get('source_key', 'unknown')
                logger.warning(f"⚠️ Source invalide {source_key}: {e}")
                invalid_sources.append(source_key)
        
        if invalid_sources:
            logger.warning(f"❌ {len(invalid_sources)} source(s) invalide(s): {invalid_sources}")
        else:
            logger.info(f"✅ Toutes les sources validées")
    
    num_sources = len(sources)
    num_bouquets = len(catalog.get('bouquets', []))
    
    logger.info(f"Catalogue chargé : {num_sources} sources, {num_bouquets} bouquets")
    
    return catalog


def load_ingestion_profiles(config_bucket: str) -> Dict[str, Any]:
    """
    Charge les profils d'ingestion depuis S3.
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict contenant les profils d'ingestion canonical
    
    Raises:
        Exception: Si les profils n'existent pas ou sont invalides
    """
    key = "canonical/ingestion/ingestion_profiles.yaml"
    logger.info("Chargement des profils d'ingestion")
    
    profiles = s3_io.read_yaml_from_s3(config_bucket, key)
    logger.info("Profils d'ingestion chargés")
    
    return profiles


def resolve_sources_for_client(
    client_config: Dict[str, Any],
    source_catalog: Dict[str, Any],
    sources_filter: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Résout les sources à traiter pour un client.
    
    Développe les bouquets en sources individuelles et applique les filtres.
    
    Args:
        client_config: Configuration du client
        source_catalog: Catalogue des sources canonical
        sources_filter: Liste optionnelle de source_key à filtrer
    
    Returns:
        Liste des sources à traiter avec leurs métadonnées complètes
    """
    logger.info("Résolution des sources pour le client")
    
    # Récupérer la config des sources du client
    source_config = client_config.get('source_config', {})
    bouquets_enabled = source_config.get('source_bouquets_enabled', [])
    sources_extra = source_config.get('sources_extra_enabled', [])
    
    logger.info(f"Bouquets activés : {bouquets_enabled}")
    logger.info(f"Sources additionnelles : {sources_extra}")
    
    # Étape 1 : Résoudre les bouquets
    source_keys = set()
    
    for bouquet_id in bouquets_enabled:
        bouquet = _find_bouquet(source_catalog, bouquet_id)
        if bouquet:
            keys = bouquet.get('source_keys', [])
            source_keys.update(keys)
            logger.info(f"Bouquet '{bouquet_id}' résolu : {len(keys)} sources")
        else:
            logger.warning(f"Bouquet '{bouquet_id}' introuvable dans le catalogue")
    
    # Étape 2 : Ajouter les sources additionnelles
    source_keys.update(sources_extra)
    
    # Étape 3 : Appliquer le filtre sources si fourni
    if sources_filter:
        source_keys = source_keys.intersection(set(sources_filter))
        logger.info(f"Filtrage sur sources spécifiques : {len(source_keys)} sources conservées")
    
    logger.info(f"Total de sources uniques après résolution : {len(source_keys)}")
    
    # Étape 4 : Récupérer les métadonnées pour chaque source
    enabled_sources = []
    disabled_count = 0
    
    for source_key in source_keys:
        source_meta = _find_source(source_catalog, source_key)
        if source_meta:
            # Filtrer sur enabled=true
            enabled = source_meta.get('enabled', False)
            ingestion_mode = source_meta.get('ingestion_mode', 'none')
            
            if not enabled:
                logger.warning(f"Source '{source_key}' est désactivée (enabled=false), ignorée")
                disabled_count += 1
            elif ingestion_mode == 'none':
                logger.warning(f"Source '{source_key}' a ingestion_mode='none', ignorée")
                disabled_count += 1
            else:
                # Copier TOUS les champs du catalog (incluant date_extraction_patterns)
                enabled_sources.append(source_meta.copy())
        else:
            logger.warning(f"Source '{source_key}' introuvable dans le catalogue")
    
    logger.info(f"Filtrage sur enabled=true : {len(enabled_sources)} sources activées, {disabled_count} sources ignorées")
    
    return enabled_sources


def resolve_period_days(
    period_days_event: Optional[int],
    client_config: Dict[str, Any],
    default: int = 7
) -> int:
    """
    Résout la valeur de period_days selon la hiérarchie de priorité.
    
    Priorité : event > client_config > défaut
    
    Args:
        period_days_event: Valeur fournie dans l'event Lambda
        client_config: Configuration du client
        default: Valeur par défaut si aucune autre n'est définie
    
    Returns:
        Nombre de jours à utiliser pour la fenêtre temporelle
    """
    # Hiérarchie de priorité
    if period_days_event is not None:
        logger.info(f"Utilisation period_days de l'event : {period_days_event}")
        return period_days_event
    
    client_period_days = client_config.get('pipeline', {}).get('default_period_days')
    if client_period_days is not None:
        logger.info(f"Utilisation period_days de la config client : {client_period_days}")
        return client_period_days
    
    logger.info(f"Utilisation period_days par défaut : {default}")
    return default


def _find_bouquet(source_catalog: Dict[str, Any], bouquet_id: str) -> Optional[Dict[str, Any]]:
    """
    Trouve un bouquet dans le catalogue par son ID.
    
    Args:
        source_catalog: Catalogue de sources
        bouquet_id: Identifiant du bouquet à trouver
    
    Returns:
        Dictionnaire du bouquet ou None si introuvable
    """
    bouquets = source_catalog.get('bouquets', [])
    for bouquet in bouquets:
        if bouquet.get('bouquet_id') == bouquet_id:
            return bouquet
    return None


def _find_source(source_catalog: Dict[str, Any], source_key: str) -> Optional[Dict[str, Any]]:
    """
    Trouve une source dans le catalogue par sa clé.
    
    Args:
        source_catalog: Catalogue de sources
        source_key: Clé de la source à trouver
    
    Returns:
        Dictionnaire de la source ou None si introuvable
    """
    sources = source_catalog.get('sources', [])
    for source in sources:
        if source.get('source_key') == source_key:
            return source
    return None


def list_client_configs(config_bucket: str) -> List[str]:
    """
    Liste tous les client_config disponibles dans S3.
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Liste des client_id disponibles
    """
    logger.info("Scan des client_config disponibles dans S3")
    
    objects = s3_io.list_objects_with_prefix(config_bucket, "clients/")
    client_ids = []
    
    for obj_key in objects:
        if obj_key.endswith('.yaml'):
            client_id = obj_key.replace('clients/', '').replace('.yaml', '')
            client_ids.append(client_id)
    
    logger.info(f"Client configs trouvés : {len(client_ids)} ({client_ids})")
    return client_ids


def load_all_client_configs(config_bucket: str) -> Dict[str, Dict[str, Any]]:
    """
    Charge toutes les configurations client depuis S3.
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict {client_id: config} pour tous les clients
    """
    logger.info("Chargement de toutes les configurations client")
    
    client_ids = list_client_configs(config_bucket)
    all_configs = {}
    
    for client_id in client_ids:
        try:
            config = load_client_config(client_id, config_bucket)
            all_configs[client_id] = config
        except Exception as e:
            logger.warning(f"Impossible de charger la config pour {client_id} : {e}")
    
    logger.info(f"Configurations chargées : {len(all_configs)}/{len(client_ids)}")
    return all_configs


def filter_active_clients(client_configs: Dict[str, Dict[str, Any]]) -> List[str]:
    """
    Filtre les clients ayant active: true dans leur configuration.
    
    Args:
        client_configs: Dict {client_id: config} de toutes les configs
    
    Returns:
        Liste des client_id ayant active: true
    """
    logger.info("Filtrage des clients actifs")
    
    active_clients = []
    
    for client_id, config in client_configs.items():
        client_profile = config.get('client_profile', {})
        is_active = client_profile.get('active', False)
        
        if is_active:
            active_clients.append(client_id)
            logger.info(f"Client actif trouvé : {client_id}")
        else:
            logger.debug(f"Client inactif ignoré : {client_id}")
    
    logger.info(f"Clients actifs : {len(active_clients)}/{len(client_configs)}")
    return active_clients


def load_canonical_scopes(config_bucket: str) -> Dict[str, Any]:
    """
    Charge tous les scopes canonical depuis S3.
    Aplatit automatiquement les scopes complexes (ex: lai_keywords).
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict contenant tous les scopes par catégorie (scopes aplatis + domains)
    """
    logger.info("Chargement des scopes canonical")
    
    all_scopes = {}
    
    # Chargement des différents types de scopes
    scope_files = {
        "companies": "canonical/scopes/company_scopes.yaml",
        "molecules": "canonical/scopes/molecule_scopes.yaml", 
        "technologies": "canonical/scopes/technology_scopes.yaml",
        "trademarks": "canonical/scopes/trademark_scopes.yaml",
        "exclusions": "canonical/scopes/exclusion_scopes.yaml"
    }
    
    for scope_type, file_path in scope_files.items():
        try:
            scope_data = s3_io.read_yaml_from_s3(config_bucket, file_path)
            
            # Aplatissement des scopes complexes
            flattened_scopes = {}
            for scope_name, scope_content in scope_data.items():
                if isinstance(scope_content, dict) and not scope_name.startswith('_'):
                    # Scope complexe : aplatir toutes les sous-catégories
                    flattened_terms = []
                    for category, terms in scope_content.items():
                        if isinstance(terms, list) and not category.startswith('_'):
                            flattened_terms.extend(terms)
                    flattened_scopes[scope_name] = flattened_terms
                    logger.info(f"Scope complexe aplati : {scope_name} ({len(flattened_terms)} termes)")
                else:
                    # Scope simple : conserver tel quel
                    flattened_scopes[scope_name] = scope_content
            
            all_scopes.update(flattened_scopes)
            logger.info(f"Scopes {scope_type} chargés : {len(flattened_scopes)} scopes")
        except Exception as e:
            logger.warning(f"Impossible de charger {file_path}: {str(e)}")
    
    # Chargement des domain definitions (NOUVEAU)
    domains = {}
    domain_files = {
        "lai_domain_definition": "canonical/domains/lai_domain_definition.yaml"
    }
    
    for domain_name, file_path in domain_files.items():
        try:
            domain_data = s3_io.read_yaml_from_s3(config_bucket, file_path)
            domains[domain_name] = domain_data
            logger.info(f"Domain definition chargée : {domain_name}")
        except Exception as e:
            logger.warning(f"Impossible de charger {file_path}: {str(e)}")
    
    # Structure finale: scopes aplatis + domains
    result = all_scopes.copy()
    if domains:
        result['domains'] = domains
        logger.info(f"Domains ajoutés : {len(domains)} domain(s)")
    
    logger.info(f"Total scopes chargés : {len(all_scopes)} scopes + {len(domains)} domain(s)")
    return result


def load_canonical_prompts(config_bucket: str) -> Dict[str, Any]:
    """
    Charge les prompts canonical depuis S3 (architecture v2.0).
    
    Structure attendue:
    - normalization/generic_normalization.yaml
    - domain_scoring/lai_domain_scoring.yaml
    - matching/lai_matching.yaml
    - editorial/lai_editorial.yaml
    
    Args:
        config_bucket: Nom du bucket de configuration S3
    
    Returns:
        Dict contenant les prompts canonical par catégorie
    """
    logger.info("Chargement des prompts canonical")
    
    all_prompts = {}
    
    # Chargement des différents types de prompts
    prompt_files = {
        "normalization": {
            "generic_normalization": "canonical/prompts/normalization/generic_normalization.yaml"
        },
        "domain_scoring": {
            "lai_domain_scoring": "canonical/prompts/domain_scoring/lai_domain_scoring.yaml"
        },
        "editorial": {
            "lai_editorial": "canonical/prompts/editorial/lai_editorial.yaml"
        }
    }
    
    for category, prompts_dict in prompt_files.items():
        category_prompts = {}
        for prompt_name, file_path in prompts_dict.items():
            try:
                prompt_data = s3_io.read_yaml_from_s3(config_bucket, file_path)
                category_prompts[prompt_name] = prompt_data
                logger.info(f"Prompt chargé : {category}/{prompt_name}")
            except Exception as e:
                logger.warning(f"Impossible de charger {file_path}: {str(e)}")
        
        if category_prompts:
            all_prompts[category] = category_prompts
            logger.info(f"Catégorie {category} : {len(category_prompts)} prompt(s) chargé(s)")
    
    # Validation structure
    if 'normalization' in all_prompts and 'generic_normalization' in all_prompts['normalization']:
        logger.info("✅ Generic normalization prompt loaded")
    else:
        logger.warning("⚠️ Generic normalization prompt missing")
    
    if 'domain_scoring' in all_prompts and 'lai_domain_scoring' in all_prompts['domain_scoring']:
        logger.info("✅ LAI domain scoring prompt loaded")
    else:
        logger.warning("⚠️ LAI domain scoring prompt missing")
    
    logger.info(f"Prompts canonical chargés : {len(all_prompts)} catégorie(s)")
    return all_prompts