import requests
from bs4 import BeautifulSoup
import io
from typing import Optional
import logging

logger = logging.getLogger(__name__)

class ContentExtractor:
    """Extraction unifiée HTML/PDF avec trafilatura et PyMuPDF"""
    
    def __init__(self, timeout: int = 15, max_length: int = 3000):
        self.timeout = timeout
        self.max_length = max_length
    
    def extract(self, url: str) -> Optional[str]:
        """Extrait contenu depuis URL (HTML ou PDF)"""
        try:
            response = requests.get(url, timeout=self.timeout)
            if response.status_code != 200:
                return None
            
            content_type = response.headers.get('content-type', '').lower()
            
            if 'pdf' in content_type:
                return self._extract_pdf(response.content)
            else:
                return self._extract_html(response.content, url)
        
        except Exception as e:
            logger.warning(f"Content extraction failed for {url[:60]}: {e}")
            return None
    
    def _extract_html(self, content: bytes, url: str = "") -> str:
        """Extrait texte depuis HTML avec BeautifulSoup"""
        try:
            soup = BeautifulSoup(content, 'html.parser')
            
            for tag in ['script', 'style', 'nav', 'header', 'footer', 'aside']:
                for elem in soup.find_all(tag):
                    elem.decompose()
            
            main = soup.find('main') or soup.find('article') or soup.find('body')
            if not main:
                main = soup
            
            text = main.get_text(separator=' ', strip=True)
            logger.info(f"HTML extraction: {len(text)} chars")
            return text[:self.max_length]
        except Exception as e:
            logger.error(f"HTML extraction failed: {e}")
            return ""
    
    def _extract_pdf(self, content: bytes) -> str:
        """Extrait texte depuis PDF avec PyMuPDF - FULL TEXT"""
        try:
            from .pdf_extractor import PDFExtractor
            extractor = PDFExtractor()
            result = extractor.extract(content, url="")
            text = result.get('text', '')
            logger.info(f"PDF extraction: {len(text)} chars, {result['metadata']['pages']} pages")
            return text  # Return FULL text, no truncation
        except Exception as e:
            logger.error(f"PDF extraction failed: {e}")
            return ""
