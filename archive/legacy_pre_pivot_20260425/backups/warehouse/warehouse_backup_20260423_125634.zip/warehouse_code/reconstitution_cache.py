#!/usr/bin/env python3
"""
Cache de reconstitution pour optimiser performance
"""

import json
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional


class ReconstitutionCache:
    """Cache pour optimiser reconstitution"""
    
    def __init__(self, cache_dir: str = "data/warehouse/cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_ttl = 3600  # 1 heure
    
    def get_cache_key(self, client_sources: List[str], period_days: int, reference_date: datetime) -> str:
        """Générer clé de cache"""
        key_data = f"{sorted(client_sources)}_{period_days}_{reference_date.date()}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def get_cached_items(self, cache_key: str) -> Optional[List[Dict]]:
        """Récupérer items depuis cache"""
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if not cache_file.exists():
            return None
        
        # Vérifier TTL
        if time.time() - cache_file.stat().st_mtime > self.cache_ttl:
            cache_file.unlink()  # Supprimer cache expiré
            return None
        
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None
    
    def cache_items(self, cache_key: str, items: List[Dict]):
        """Mettre en cache les items"""
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(items, f, ensure_ascii=False)
        except Exception:
            pass  # Ignore cache errors
            