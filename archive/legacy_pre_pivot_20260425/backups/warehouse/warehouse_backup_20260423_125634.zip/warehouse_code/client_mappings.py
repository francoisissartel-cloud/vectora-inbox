#!/usr/bin/env python3
"""
Gestionnaire des mappings client vers sources et écosystèmes
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class ClientMappingManager:
    """Gestionnaire des mappings client → écosystème + sources"""
    
    def __init__(self, mappings_file: str = "data/warehouse/client_mappings.json"):
        self.mappings_file = Path(mappings_file)
        self._mappings = self._load_mappings()
    
    def _load_mappings(self) -> Dict:
        """Charger les mappings depuis le fichier"""
        try:
            with open(self.mappings_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading client mappings: {e}")
            return {"version": "1.0", "mappings": {}}
    
    def get_ecosystem_for_client(self, client_id: str) -> Optional[str]:
        """Récupérer l'écosystème pour un client"""
        client_mapping = self._mappings.get("mappings", {}).get(client_id)
        if client_mapping:
            return client_mapping.get("ecosystem")
        return None
    
    def get_sources_for_client(self, client_id: str) -> List[str]:
        """Récupérer les sources pour un client"""
        client_mapping = self._mappings.get("mappings", {}).get(client_id)
        if client_mapping:
            return client_mapping.get("sources", [])
        return []
    
    def get_bouquets_for_client(self, client_id: str) -> List[str]:
        """Récupérer les bouquets pour un client"""
        client_mapping = self._mappings.get("mappings", {}).get(client_id)
        if client_mapping:
            return client_mapping.get("bouquets", [])
        return []
    
    def resolve_ecosystem_from_watch_domains(self, client_config: Dict) -> Optional[str]:
        """Résoudre l'écosystème depuis watch_domains du client config"""
        watch_domains = client_config.get("watch_domains", [])
        if watch_domains and len(watch_domains) > 0:
            return watch_domains[0].get("id")
        return None
    
    def add_client_mapping(self, client_id: str, ecosystem: str, sources: List[str], bouquets: List[str] = None):
        """Ajouter un mapping client"""
        if "mappings" not in self._mappings:
            self._mappings["mappings"] = {}
        
        self._mappings["mappings"][client_id] = {
            "ecosystem": ecosystem,
            "sources": sources,
            "bouquets": bouquets or []
        }
        
        self._save_mappings()
    
    def _save_mappings(self):
        """Sauvegarder les mappings"""
        self._mappings["last_updated"] = datetime.now().isoformat()
        
        with open(self.mappings_file, 'w', encoding='utf-8') as f:
            json.dump(self._mappings, f, indent=2, ensure_ascii=False)