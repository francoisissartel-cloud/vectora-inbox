"""Package newsletter - Assemblage de la newsletter finale (Phase 4)."""
